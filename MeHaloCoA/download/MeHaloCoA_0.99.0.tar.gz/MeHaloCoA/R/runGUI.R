runGUI<-function(){
    dial()
    print("<----Detection Started--->")
}